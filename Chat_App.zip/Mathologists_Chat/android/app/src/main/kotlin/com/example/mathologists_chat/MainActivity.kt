package com.example.mathologists_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
